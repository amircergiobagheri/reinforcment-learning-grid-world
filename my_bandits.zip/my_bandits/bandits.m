clc;
clear;
close all; 
%%
cycle=1000;  plays=2000; num_bandits=20; variance=1;
m1=zeros(plays,cycle); m11=zeros(plays,cycle);
best_machine1=zeros(plays,cycle); best_machine2=zeros(plays,cycle);
q=zeros(num_bandits,cycle); epsilon=[0.01 0.2 ];
%%
 for i=1:plays
     meu=randn(num_bandits,1);
     [~,a_star]=max(meu);
     for j=1:num_bandits
         q(j,:)=normrnd(meu(j),variance,1,cycle); %estimation
     end
     [Q,best]=agent(q,a_star,epsilon,cycle,num_bandits);  % agent
     m1(i,:)=Q(1,:);       % reward from agent
     best_machine1(i,:)=best(1,:);       % best action agent
     m11(i,:)=Q(2,:);
     best_machine2(i,:)=best(2,:);
 end
plotResullt(m1,best_machine1,m11,best_machine2);



     

