function [Q,best]=agent(q,b,e,cycle,num_bandits)  
% output : Q   % input : q matrix & b best machine & e epsilon
Q=zeros(2,cycle);
B=zeros(1,num_bandits);
step=zeros(1,num_bandits);
step1=zeros(1,num_bandits);
best=zeros(2,cycle);
for i=1:cycle
    if rand<=e(1)
        Max_n=randi(num_bandits,1);
        Max=B(Max_n);
    else
        [Max,Max_n]=max(B);
    end
    step(Max_n)=step(Max_n) + 1 ; % counter
    reward=q(Max_n,step(Max_n));
    B(Max_n)=Max+(reward-Max)/step(Max_n);           % incremental method
%     B(Max_n)=exp(reward/100) / sum(exp(reward/100));
    Q(1,i)=reward;

    if Max_n==b
        best(1,i)=1;
    end
    %% 
        if rand<=e(2)
        Maxx_n=randi(num_bandits,1);
        Maxx=B(Maxx_n);
    else
        [Maxx,Maxx_n]=max(B);
    end
    step1(Maxx_n)=step1(Maxx_n) + 1 ; % counter
    rewardd=q(Maxx_n,step1(Maxx_n));
    B(Maxx_n)=Maxx+(rewardd-Max)/step1(Maxx_n);           % incremental method
%     B(Max_n)=exp(reward/100) / sum(exp(reward/100));
    Q(2,i)=rewardd;

    if Maxx_n==b
        best(2,i)=1;
    end
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
end















end


