function plotResullt(m1,m2,m11,m22)
q1=mean(m1); q2=mean(m2);q11=mean(m11); q22=mean(m22);
figure,
subplot(2,1,1);
plot(q1,'r');
hold on
plot(q11,'g');
ylabel('average rewards'),xlabel('plays'),t1=text(265,1.158,'\leftarrow 0.01');
t2=text(802,1.52,'\leftarrow 0.2');
t1(1).Color = 'black';
t1(1).FontSize = 18;
t2(1).Color = 'black';
t2(1).FontSize = 18;
grid on
subplot(2,1,2);
plot(q2,'r');
hold on
plot(q22,'g');
ylabel('optimal action'),xlabel('plays'),t1=text(443,0.737,'\leftarrow 0.2');
t2=text(798,0.644,'\leftarrow 0.01');
t1(1).Color = 'black';
t1(1).FontSize = 19;
t2(1).Color = 'black';
t2(1).FontSize = 19;
grid on
figure,
subplot(2,1,1);
histfit(q2,80,'kernel')
ylabel('optimal action'),xlabel('plays')
subplot(2,1,2);
histfit(q22,80,'kernel')
ylabel('optimal action'),xlabel('plays')


end