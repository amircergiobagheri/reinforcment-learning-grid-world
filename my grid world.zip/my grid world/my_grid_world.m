clc;clear;close all;
format shortG
N=5;
Value=zeros(N);
error=1000;
e=0.0001;
c=0;
while error>e
    c=c+1;
    Value_new=zeros(N);
    for y=1:N
        for x=1:N
            for action=1:4
            [x_new,y_new,reward]=actionn(x,y,action);
            Value_new(x,y)= Value_new(x,y)+0.25*(reward+0.9*Value(x_new,y_new));
            
            end
        end
    end
error=max(max(Value_new-Value));
Value=Value_new;
end
x=rot90(Value);
y=rot90(x);
disp('************************************************<<Values>>*********************************************************')
disp(flip(y,2))
disp('************************************************<<Values>>*********************************************************')


            
            
        
        
    