function [x_new,y_new,reward]=actionn(x,y,action)

    if (x==5) && (y==2)
        reward=10;
        y_new=2;
        x_new=1;
    elseif (y==4) && (x==5)
            reward=5;
            y_new=4;
            x_new=3;
    else
        if action==1 
            y_new=y+1;
            x_new=x;
            reward=0;
            if y_new>5
                y_new=y_new-1;
                reward=-1;
            end
        end
        if action==2  
            y_new=y-1;
            x_new=x;
            reward=0;
            if y_new<1
                y_new=y_new+1;
                reward=-1;
            end
        end
        if action==3 
            x_new=x+1;
            y_new=y;
            reward=0;
            if x_new>5
                x_new=x_new-1;
                reward=-1;
            end
        end
        if action==4 
            x_new=x-1;
            y_new=y;
            reward=0;
            if x_new<1
                x_new=x_new+1;
                reward=-1;
            end
        end
    end
end
                
                
            
            
            